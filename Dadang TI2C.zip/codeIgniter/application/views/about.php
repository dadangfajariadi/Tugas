<!DOCTYPE html>
<html lang="">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Title Page</title>

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">

		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.2/html5shiv.min.js"></script>
			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	</head>
	<body>
		<div class="container">
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
				<nav class="navbar navbar-default" role="navigation">
					<div class="container-fluid">
						<!-- Brand and toggle get grouped for better mobile display -->
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
							<a class="navbar-brand" href=" ">Welcome</a>
						</div>
				
						<!-- Collect the nav links, forms, and other content for toggling -->
						<div class="collapse navbar-collapse navbar-ex1-collapse">
							<ul class="nav navbar-nav">
								<li><a href="<?php echo site_url()?>/home">Home</a></li>
								<li class="active"><a href="<?php echo site_url()?>/about">About</a></li>
								<li><a href="<?php echo site_url()?>/contact">Contact</a></li>
							</ul>								
							<ul class="nav navbar-nav navbar-right">
								<li class="dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown">Administrator<b class="caret"></b></a>
									<ul class="dropdown-menu">
										<li><a href="<?php echo site_url()?>/home">Home</a></li>
										<li><a href="<?php echo site_url()?>/about">About</a></li>
										<li><a href="<?php echo site_url()?>/contact">Contact</a></li>
									</ul>
								</li>
							</ul>
						</div><!-- /.navbar-collapse -->
					</div>
				</nav>
					<div class="jumbotron">
						<div class="container">
							<h1>Halaman About</h1>
							
						</div>
					</div>
					<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
						<table class="table table-hover">
							<thead>
								<tr>
									<th>Biodata</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>Nama</td>
								</tr>
							</tbody>
							<tbody>
								<tr>
									<td>TTL</td>
								</tr>
							</tbody>
							<tbody>
								<tr>
									<td>Alamat</td>
								</tr>
							</tbody>
							<tbody>
								<tr>
									<td>Agama</td>
								</tr>
							</tbody>
							<tbody>
								<tr>
									<td>Hobi</td>
								</tr>
							</tbody>
							<tbody>
								<tr>
									<td>Email</td>
								</tr>
							</tbody>
							<tbody>
								<tr>
									<td>No Telepon</td>
								</tr>
							</tbody>

						</table>
					</div>
					<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
						<table class="table table-hover">
							<thead>
								<tr>
									<th>:</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>Dadang Fajariadi</td>
								</tr>
							</tbody>
							<tbody>
								<tr>
									<td>Tulungagung, 09-02-1997</td>
								</tr>
							</tbody>
							<tbody>
								<tr>
									<td>Jalan Simpang Bunga Andong kav 5</td>
								</tr>
							</tbody>
							<tbody>
								<tr>
									<td>Islam</td>
								</tr>
							</tbody>
							<tbody>
								<tr>
									<td>Ngoding</td>
								</tr>
							</tbody>
							<tbody>
								<tr>
									<td>dfajariadi@gmail.com</td>
								</tr>
							</tbody>
							<tbody>
								<tr>
									<td>082257574821</td>
								</tr>
							</tbody>
						</table>
					</div>
					<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
						<table class="table table-hover">
							<thead>
								<tr>
									<th>Keterangan</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>Eat Sleep Cooding Repeat</td>
								</tr>
							</tbody>
						</table>
					</div>
			</div>
		</div>

		<!-- jQuery -->
		<script src="//code.jquery.com/jquery.js"></script>
		<!-- Bootstrap JavaScript -->
		<script src="<?php echo base_url()?>assets/js/bootstrap.min.js"></script>
		<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
 		<script src="Hello World"></script>
	</body>
</html>